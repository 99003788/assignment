var searchData=
[
  ['enter_5fdetails_6',['enter_details',['../box_8h.html#a79fb60ae4584326973a0cb669e8d42f2',1,'box.h']]]
];
