var searchData=
[
  ['enter_5fdetails_2',['enter_details',['../box_8h.html#a79fb60ae4584326973a0cb669e8d42f2',1,'box.h']]]
];
