@mainpage Box Activity implementation by
A H Aruna, Karisma Kiran, Sayani basak, Souvik Jana, Suvradeep Datta
@subpage box.h