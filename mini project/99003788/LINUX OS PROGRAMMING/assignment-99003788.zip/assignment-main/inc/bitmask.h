#ifndef __BITMASK_H
#define __BITMASK_H

int setBit(int num1 ,int bit) ;

int reset ( int num ,int bit) ;

int flip_no(int num ,int  flippedNumb) ;

#endif