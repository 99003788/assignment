#ifndef __MYSTRING_H
#define __MYSTRING_H


int findLength(char *str);

char* concatenateString(char *str1, char *str2);

int compareString(char *str1 , char *str2);

char* stringCopy(char *str1 , char *str2) ;

#endif