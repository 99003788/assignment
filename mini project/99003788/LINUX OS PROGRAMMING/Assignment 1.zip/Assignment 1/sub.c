#include<stdio.h>
#include"calc.h"
void sub()
{
    int n1,n2;
    printf("\nEnter the two Number :\n");
    scanf("%d%d",&n1,&n2);
    printf("Subtraction is : %d\n\n",n1-n2);
}
