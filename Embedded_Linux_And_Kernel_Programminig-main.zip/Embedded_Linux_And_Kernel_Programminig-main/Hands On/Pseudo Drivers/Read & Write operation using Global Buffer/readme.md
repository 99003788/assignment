# -> Creating Class and Device
# -> Reading and Writing operation using Global Buffer

